const fetch = require('node-fetch');
const config = require('./config/crew_ai');

async function getAIResponse(userMessage) {
  const response = await fetch(config.endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${config.apiKey}`,
    },
    body: JSON.stringify({ message: userMessage }),
  });

  const data = await response.json();
  return data.reply;
}

module.exports = getAIResponse;