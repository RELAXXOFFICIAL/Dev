module.exports = {
  endpoint: 'https://api.crew.ai/v1/chat',
  apiKey: 'sk-proj-nn6VLAwxzhe9nIpPDQRNT3BlbkFJ9FX93NSB65JE283utfNC',
};