import React from 'react';
import './styles/App.css';
import Chatbot from './components/Chatbot';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Welcome to My Enhanced Full Stack App</h1>
      </header>
      <main>
        <Chatbot />
      </main>
      <footer className="App-footer">
        <p>© 2024 My Full Stack App</p>
      </footer>
    </div>
  );
}

export default App;